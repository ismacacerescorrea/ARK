<?php

/**
 * @file plugins/pubIds/ark/index.php
 * 
 * Plugin for ARK (Archival Resource Key) persistent identifiers in OJS 3.5.
 * Copyright (c) 2014-2025 Simon Fraser University
 * Copyright (c) 2003-2025 John Willinsky
 * Distributed under the GNU GPL v3. For full terms see the file https://www.gnu.org/licenses/gpl-3.0.txt
 *
 * Este plugin ARK para OJS 3.5 fue modificado por Ismael Cáceres-Correa en 2025 (Concepción, Chile).
 *
 * @brief Wrapper for ark plugin.
 *
 */

return new \APP\plugins\pubIds\ark\ARKPubIdPlugin();
