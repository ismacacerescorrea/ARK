<?php

/**
 * @file plugins/pubIds/ark/classes/form/ARKSettingsForm.php
 *
 * Plugin for ARK (Archival Resource Key) persistent identifiers in OJS 3.5.
 * Copyright (c) 2014-2025 Simon Fraser University
 * Copyright (c) 2003-2025 John Willinsky
 * Distributed under the GNU GPL v3. For full terms see the file https://www.gnu.org/licenses/gpl-3.0.txt
 *
 * Este plugin ARK para OJS 3.5 fue modificado por Ismael C��ceres-Correa en 2025 (Concepci��n, Chile).
 *
 * @class ARKSettingsForm
 *
 * @brief Form for journal managers to setup ARK plugin
 */

namespace APP\plugins\pubIds\ark\classes\form;

use APP\core\Application;
use APP\plugins\pubIds\ark\ARKPubIdPlugin;
use APP\template\TemplateManager;
use PKP\form\Form;
use PKP\linkAction\LinkAction;
use PKP\linkAction\request\RemoteActionConfirmationModal;

class ARKSettingsForm extends Form
{
    /** @var int */
    public $_contextId;

    /**
     * Get the context ID.
     *
     * @return int
     */
    public function _getContextId()
    {
        return $this->_contextId;
    }

    /** @var ARKPubIdPlugin */
    public $_plugin;

    /**
     * Get the plugin.
     *
     * @return ARKPubIdPlugin
     */
    public function _getPlugin()
    {
        return $this->_plugin;
    }

    /**
     * Constructor
     *
     * @param ARKPubIdPlugin $plugin
     * @param int $contextId
     */
    public function __construct($plugin, $contextId)
    {
        $this->_contextId = $contextId;
        $this->_plugin = $plugin;

        parent::__construct($plugin->getTemplateResource('settingsForm.tpl'));

        $form = $this;
        $this->addCheck(new \PKP\form\validation\FormValidatorCustom($this, 'arkObjects', 'required', 'plugins.pubIds.ark.manager.settings.arkObjectsRequired', function ($enableIssueARK) use ($form) {
            return $form->getData('enableIssueARK') || $form->getData('enablePublicationARK') || $form->getData('enableRepresentationARK');
        }));
        $this->addCheck(new \PKP\form\validation\FormValidatorRegExp($this, 'arkPrefix',
        'required',
        'plugins.pubIds.ark.manager.settings.form.arkPrefixPattern',
        '/^ark:[a-zA-Z0-9\/]+$/'));
        
        $this->addCheck(new \PKP\form\validation\FormValidatorCustom($this, 'arkIssueSuffixPattern', 'required', 'plugins.pubIds.ark.manager.settings.form.arkIssueSuffixPatternRequired', function ($arkIssueSuffixPattern) use ($form) {
            if ($form->getData('arkSuffix') == 'pattern' && $form->getData('enableIssueARK')) {
                return $arkIssueSuffixPattern != '';
            }
            return true;
        }));
        $this->addCheck(new \PKP\form\validation\FormValidatorCustom($this, 'arkPublicationSuffixPattern', 'required', 'plugins.pubIds.ark.manager.settings.form.arkPublicationSuffixPatternRequired', function ($arkPublicationSuffixPattern) use ($form) {
            if ($form->getData('arkSuffix') == 'pattern' && $form->getData('enablePublicationARK')) {
                return $arkPublicationSuffixPattern != '';
            }
            return true;
        }));
        $this->addCheck(new \PKP\form\validation\FormValidatorCustom($this, 'arkRepresentationSuffixPattern', 'required', 'plugins.pubIds.ark.manager.settings.form.arkRepresentationSuffixPatternRequired', function ($arkRepresentationSuffixPattern) use ($form) {
            if ($form->getData('arkSuffix') == 'pattern' && $form->getData('enableRepresentationARK')) {
                return $arkRepresentationSuffixPattern != '';
            }
            return true;
        }));
        $this->addCheck(new \PKP\form\validation\FormValidatorUrl($this, 'arkResolver', 'required', 'plugins.pubIds.ark.manager.settings.form.arkResolverRequired'));
        $this->addCheck(new \PKP\form\validation\FormValidatorPost($this));
        $this->addCheck(new \PKP\form\validation\FormValidatorCSRF($this));

        // for ARK reset requests
        $request = Application::get()->getRequest();
        $this->setData('clearPubIdsLinkAction', new LinkAction(
            'reassignARKs',
            new RemoteActionConfirmationModal(
                $request->getSession(),
                __('plugins.pubIds.ark.manager.settings.arkReassign.confirm'),
                __('common.delete'),
                $request->url(null, null, 'manage', null, ['verb' => 'clearPubIds', 'plugin' => $plugin->getName(), 'category' => 'pubIds']),
                'negative'
            ),
            __('plugins.pubIds.ark.manager.settings.arkReassign'),
            'delete'
        ));
        $this->setData('pluginName', $plugin->getName());
    }

    public function fetch($request, $template = null, $display = false)
    {
        // Desactivamos visualmente los espacios de nombre
        $arkNamespaces = []; // Se conserva la variable pero no se asignan valores
        $templateMgr = TemplateManager::getManager($request);
        $templateMgr->assign('arkNamespaces', $arkNamespaces);
        return parent::fetch($request, $template, $display);
    }

    public function initData()
    {
        $contextId = $this->_getContextId();
        $plugin = $this->_getPlugin();
        foreach ($this->_getFormFields() as $fieldName => $fieldType) {
            $this->setData($fieldName, $plugin->getSetting($contextId, $fieldName));
        }
    }

    public function readInputData()
    {
        $this->readUserVars(array_keys($this->_getFormFields()));
    }

    public function execute(...$functionArgs)
    {
        $contextId = $this->_getContextId();
        $plugin = $this->_getPlugin();
        foreach ($this->_getFormFields() as $fieldName => $fieldType) {
            $plugin->updateSetting($contextId, $fieldName, $this->getData($fieldName), $fieldType);
        }
        parent::execute(...$functionArgs);
    }

    public function _getFormFields()
    {
        return [
            'enableIssueARK' => 'bool',
            'enablePublicationARK' => 'bool',
            'enableRepresentationARK' => 'bool',
            'arkPrefix' => 'string',
            'arkSuffix' => 'string',
            'arkIssueSuffixPattern' => 'string',
            'arkPublicationSuffixPattern' => 'string',
            'arkRepresentationSuffixPattern' => 'string',
            'arkCheckNo' => 'bool', // Inactivo, se conserva
            'arkNamespace' => 'string', // Inactivo, no visible
            'arkResolver' => 'string',
        ];
    }
}
