<?php

/**
 * @file plugins/pubIds/ark/classes/form/FieldTextArk.php
 *
 * Copyright (c) 2014-2022 Simon Fraser University
 * Copyright (c) 2000-2022 John Willinsky
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @class FieldTextArk
 *
 * @brief A field for entering a custom ARK that also considers adding a check number.
 */

namespace APP\plugins\pubIds\ark\classes\form;

use PKP\components\forms\FieldText;

class FieldTextArk extends FieldText
{
    /** @copydoc Field::$component */
    public $component = 'field-text-ark';

    public string $arkPrefix = '';

    public bool $applyCheckNumber = false;

    /**
     * @copydoc Field::getConfig()
     */
    public function getConfig()
    {
        $config = parent::getConfig();
        $config['arkPrefix'] = $this->arkPrefix;
        $config['applyCheckNumber'] = $this->applyCheckNumber;
        $config['addCheckNumberLabel'] = __('plugins.pubIds.ark.editor.addCheckNo');
        return $config;
    }
}
