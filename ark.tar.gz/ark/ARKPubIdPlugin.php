<?php

/**
 * @file plugins/pubIds/ark/ARKPubIdPlugin.php
 *
 * Copyright (c) 2014-2022 Simon Fraser University
 * Copyright (c) 2003-2022 John Willinsky
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @class ARKPubIdPlugin
 *
 * @brief ARK plugin class
 */

namespace APP\plugins\pubIds\ark;

use APP\components\forms\publication\PublishForm;
use APP\core\Application;
use APP\facades\Repo;
use APP\issue\Issue;
use APP\plugins\PubIdPlugin;
use APP\plugins\pubIds\ark\classes\form\FieldPubIdArk;
use APP\plugins\pubIds\ark\classes\form\FieldTextArk;
use APP\plugins\pubIds\ark\classes\form\ARKSettingsForm;
use APP\template\TemplateManager;
use Illuminate\Support\Str;
use PKP\components\forms\FormComponent;
use PKP\components\forms\publication\PKPPublicationIdentifiersForm;
use PKP\linkAction\LinkAction;
use PKP\linkAction\request\RemoteActionConfirmationModal;
use PKP\plugins\Hook;

class ARKPubIdPlugin extends PubIdPlugin
{
    /**
     * @copydoc Plugin::register()
     *
     * @param null|mixed $mainContextId
     */
    public function register($category, $path, $mainContextId = null)
    {
        $success = parent::register($category, $path, $mainContextId);
        if (Application::isUnderMaintenance()) {
            return $success;
        }
        if ($success && $this->getEnabled($mainContextId)) {
            Hook::add('Publication::validate', $this->validatePublicationArk(...));
            Hook::add('Form::config::before', $this->addPublicationFormFields(...));
            Hook::add('Form::config::before', $this->addPublishFormNotice(...));
            Hook::add('TemplateManager::display', $this->loadArkFieldComponent(...));
        }
        return $success;
    }

    //
    // Implement template methods from Plugin.
    //
    /**
     * @copydoc Plugin::getDisplayName()
     */
    public function getDisplayName()
    {
        return __('plugins.pubIds.ark.displayName');
    }

    /**
     * @copydoc Plugin::getDescription()
     */
    public function getDescription()
    {
        return __('plugins.pubIds.ark.description');
    }

    //
    // Implement template methods from PubIdPlugin.
    //
    /**
     * @copydoc PKPPubIdPlugin::constructPubId()
     */
    public function constructPubId($pubIdPrefix, $pubIdSuffix, $contextId)
    {
        $ark = $pubIdPrefix . $pubIdSuffix;
        $suffixFieldName = $this->getSuffixFieldName();
        $suffixGenerationStrategy = $this->getSetting($contextId, $suffixFieldName);
        // checkNo is already calculated for custom suffixes (not used for ARK, but retained for compatibility)
        if ($suffixGenerationStrategy != 'customId' && $this->getSetting($contextId, 'arkCheckNo')) {
            $ark .= $this->_calculateCheckNo($ark);
        }
        return $ark;
    }

    /**
     * @copydoc PKPPubIdPlugin::getPubIdType()
     */
    public function getPubIdType()
    {
        return 'other::ark';
    }


    /**
     * @copydoc PKPPubIdPlugin::getPubIdDisplayType()
     */
    public function getPubIdDisplayType()
    {
        return 'ARK';
    }

    /**
     * @copydoc PKPPubIdPlugin::getPubIdFullName()
     */
    public function getPubIdFullName()
    {
        return 'Archival Resource Key';
    }

    /**
     * @copydoc PKPPubIdPlugin::getResolvingURL()
     */
    public function getResolvingURL($contextId, $pubId)
    {
        $resolverURL = $this->getSetting($contextId, 'arkResolver');
        return $resolverURL . $pubId;
    }

    /**
     * @copydoc PKPPubIdPlugin::getPubIdMetadataFile()
     */
    public function getPubIdMetadataFile()
    {
        return $this->getTemplateResource('arkSuffixEdit.tpl');
    }

    /**
     * @copydoc PKPPubIdPlugin::addJavaScript()
     */
    public function addJavaScript($request, $templateMgr)
    {
        $templateMgr->addJavaScript(
            'arkCheckNo',
            "{$request->getBaseUrl()}/{$this->getPluginPath()}/js/checkNumber.js",
            [
                'inline' => false,
                'contexts' => ['publicIdentifiersForm', 'backend'],
            ]
        );
    }

    /**
     * @copydoc PKPPubIdPlugin::getPubIdAssignFile()
     */
    public function getPubIdAssignFile()
    {
        return $this->getTemplateResource('arkAssign.tpl');
    }

    /**
     * @copydoc PKPPubIdPlugin::instantiateSettingsForm()
     */
    public function instantiateSettingsForm($contextId)
    {
        return new ARKSettingsForm($this, $contextId);
    }

    /**
     * @copydoc PKPPubIdPlugin::getFormFieldNames()
     */
    public function getFormFieldNames()
    {
        return ['arkSuffix'];
    }

    /**
     * @copydoc PKPPubIdPlugin::getAssignFormFieldName()
     */
    public function getAssignFormFieldName()
    {
        return 'assignARK';
    }

    /**
     * @copydoc PKPPubIdPlugin::getPrefixFieldName()
     */
    public function getPrefixFieldName()
    {
        return 'arkPrefix';
    }

    /**
     * @copydoc PKPPubIdPlugin::getSuffixFieldName()
     */
    public function getSuffixFieldName()
    {
        return 'arkSuffix';
    }

    /**
     * @copydoc PKPPubIdPlugin::getLinkActions()
     */
    public function getLinkActions($pubObject)
    {
        $linkActions = [];
        $request = Application::get()->getRequest();
        $userVars = $request->getUserVars();
        $classNameParts = explode('\\', get_class($this)); // Separate namespace info from class name
        $userVars['pubIdPlugIn'] = end($classNameParts);
        // Clear object pub id
        $linkActions['clearPubIdLinkActionARK'] = new LinkAction(
            'clearPubId',
            new RemoteActionConfirmationModal(
                $request->getSession(),
                __('plugins.pubIds.ark.editor.clearObjectsARK.confirm'),
                __('common.delete'),
                $request->url(null, null, 'clearPubId', null, $userVars),
                'negative'
            ),
            __('plugins.pubIds.ark.editor.clearObjectsARK'),
            'delete',
            __('plugins.pubIds.ark.editor.clearObjectsARK')
        );

        if ($pubObject instanceof Issue) {
            // Clear issue objects pub ids
            $linkActions['clearIssueObjectsPubIdsLinkActionARK'] = new LinkAction(
                'clearObjectsPubIds',
                new RemoteActionConfirmationModal(
                    $request->getSession(),
                    __('plugins.pubIds.ark.editor.clearIssueObjectsARK.confirm'),
                    __('common.delete'),
                    $request->url(null, null, 'clearIssueObjectsPubIds', null, $userVars),
                    'negative'
                ),
                __('plugins.pubIds.ark.editor.clearIssueObjectsARK'),
                'delete',
                __('plugins.pubIds.ark.editor.clearIssueObjectsARK')
            );
        }

        return $linkActions;
    }

    /**
     * @copydoc PKPPubIdPlugin::getSuffixPatternsFieldName()
     */
    public function getSuffixPatternsFieldNames()
    {
        return  [
            'Issue' => 'arkIssueSuffixPattern',
            'Publication' => 'arkPublicationSuffixPattern',
            'Representation' => 'arkRepresentationSuffixPattern',
        ];
    }

    /**
     * @copydoc PKPPubIdPlugin::getDAOFieldNames()
     */
    public function getDAOFieldNames()
    {
        return ['pub-id::other::ark'];
    }

    /**
     * @copydoc PKPPubIdPlugin::isObjectTypeEnabled()
     */
    public function isObjectTypeEnabled($pubObjectType, $contextId)
    {
        return (bool) $this->getSetting($contextId, "enable{$pubObjectType}ARK");
    }

    /**
     * @copydoc PKPPubIdPlugin::isObjectTypeEnabled()
     */
    public function getNotUniqueErrorMsg()
    {
        return __('plugins.pubIds.ark.editor.arkSuffixCustomIdentifierNotUnique');
    }

    /**
     * @copydoc PKPPubIdPlugin::getDAOs()
     */
    public function getDAOs()
    {
        return  [
            Repo::issue()->dao,
            Repo::publication()->dao,
            Application::getRepresentationDAO(),
        ];
    }

    /**
     * Validate a publication's ARK against the plugin's settings
     */
    public function validatePublicationArk(string $hookName, array $args): void
    {
        $errors = & $args[0];
        $object = $args[1];
        $props = & $args[2];

        if (empty($props['pub-id::other::ark'])) {
            return;
        }

        if (is_null($object)) {
            $submission = Repo::submission()->get($props['submissionId']);
        } else {
            $publication = Repo::publication()->get($props['id']);
            $submission = Repo::submission()->get($publication->getData('submissionId'));
        }

        $contextId = $submission->getData('contextId');
        $arkPrefix = $this->getSetting($contextId, 'arkPrefix');

        $arkErrors = [];
        if (strpos($props['pub-id::other::ark'], $arkPrefix) !== 0) {
            $arkErrors[] = __('plugins.pubIds.ark.editor.missingPrefix', ['arkPrefix' => $arkPrefix]);
        }
        if (!$this->checkDuplicate($props['pub-id::other::ark'], $publication, $contextId)) {
            $arkErrors[] = $this->getNotUniqueErrorMsg();
        }
        if (!empty($arkErrors)) {
            $errors['pub-id::other::ark'] = $arkErrors;
        }
    }

    /**
     * Add ARK fields to the publication identifiers form
     */
    public function addPublicationFormFields(string $hookName, FormComponent $form): void
    {
        if ($form->id !== 'publicationIdentifiers') {
            return;
        }
        /** @var PKPPublicationIdentifiersForm $form */
        if (!$this->getSetting($form->submissionContext->getId(), 'enablePublicationARK')) {
            return;
        }

        $prefix = $this->getSetting($form->submissionContext->getId(), 'arkPrefix');

        $suffixType = $this->getSetting($form->submissionContext->getId(), 'arkSuffix');
        $pattern = '';
        if ($suffixType === 'default') {
            $pattern = '%j.v%vi%i.%a';
        } elseif ($suffixType === 'pattern') {
            $pattern = $this->getSetting($form->submissionContext->getId(), 'arkPublicationSuffixPattern');
        }

        $appyCheckNumber = $this->getSetting($form->submissionContext->getId(), 'arkCheckNo');

        // If a pattern exists, use a DOI-like field to generate the ARK
        if ($pattern) {
            $fieldData = [
                'label' => __('plugins.pubIds.ark.displayName'),
                'value' => $form->publication->getData('pub-id::other::ark'),
                'prefix' => $prefix,
                'pattern' => $pattern,
                'contextInitials' => preg_replace('/[^-._;()\/A-Za-z0-9]/', '', Str::lower($form->submissionContext->getData('acronym', $form->submissionContext->getData('primaryLocale')) ?? '')),
                'submissionId' => $form->publication->getData('submissionId'),
                'assignIdLabel' => __('plugins.pubIds.ark.editor.ark.assignArk'),
                'clearIdLabel' => __('plugins.pubIds.ark.editor.clearObjectsARK'),
                'applyCheckNumber' => $appyCheckNumber,
            ];
            if ($form->publication->getData('pub-id::publisher-id')) {
                $fieldData['publisherId'] = $form->publication->getData('pub-id::publisher-id');
            }
            if ($form->publication->getData('pages')) {
                $fieldData['pages'] = $form->publication->getData('pages');
            }
            if ($form->publication->getData('issueId')) {
                $issue = Repo::issue()->get($form->publication->getData('issueId'));
                if ($issue) {
                    $fieldData['issueNumber'] = $issue->getNumber() ?? '';
                    $fieldData['issueVolume'] = $issue->getVolume() ?? '';
                    $fieldData['year'] = $issue->getYear() ?? '';
                }
            }
            if ($suffixType === 'default') {
                $fieldData['missingPartsLabel'] = __('plugins.pubIds.ark.editor.missingIssue');
            } else {
                $fieldData['missingPartsLabel'] = __('plugins.pubIds.ark.editor.missingParts');
            }
            $form->addField(new FieldPubIdArk('pub-id::other::ark', $fieldData));

            // Otherwise add a field for manual entry that includes a button to generate
            // the check number
        } else {
            $form->addField(new FieldTextArk('pub-id::other::ark', [
                'label' => __('plugins.pubIds.ark.displayName'),
                'description' => __('plugins.pubIds.ark.editor.ark.description', ['prefix' => $prefix]),
                'value' => $form->publication->getData('pub-id::other::ark'),
                'arkPrefix' => $prefix,
                'applyCheckNumber' => $appyCheckNumber,
            ]));
        }
    }

    /**
     * Show ARK during final publish step
     */
    public function addPublishFormNotice(string $hookName, FormComponent $form): void
    {
        if ($form->id !== 'publish' || !empty($form->errors)) {
            return;
        }
        /** @var PublishForm $form */
        $submission = Repo::submission()->get($form->publication->getData('submissionId'));
        $publicationArkEnabled = $this->getSetting($submission->getData('contextId'), 'enablePublicationARK');
        $galleyArkEnabled = $this->getSetting($submission->getData('contextId'), 'enableRepresentationARK');
        $warningIconHtml = '<span class="fa fa-exclamation-triangle pkpIcon--inline"></span>';

        if (!$publicationArkEnabled && !$galleyArkEnabled) {
            return;

            // Use a simplified view when only assigning to the publication
        } elseif (!$galleyArkEnabled) {
            if ($form->publication->getData('pub-id::other::ark')) {
                $msg = __('plugins.pubIds.ark.editor.preview.publication', ['ark' => $form->publication->getData('pub-id::other::ark')]);
            } else {
                $msg = '<div class="pkpNotification pkpNotification--warning">' . $warningIconHtml . __('plugins.pubIds.ark.editor.preview.publication.none') . '</div>';
            }
            $form->addField(new \PKP\components\forms\FieldHTML('ark', [
                'description' => $msg,
                'groupId' => 'default',
            ]));
            return;

            // Show a table if more than one ARK is going to be created
        } else {
            $arkTableRows = [];
            if ($publicationArkEnabled) {
                if ($form->publication->getData('pub-id::other::ark')) {
                    $arkTableRows[] = [$form->publication->getData('pub-id::other::ark'), 'Publication'];
                } else {
                    $arkTableRows[] = [$warningIconHtml . __('submission.status.unassigned'), 'Publication'];
                }
            }
            if ($galleyArkEnabled) {
                foreach ($form->publication->getData('galleys') as $galley) {
                    if ($galley->getStoredPubId('other::ark')) {
                        $arkTableRows[] = [$galley->getStoredPubId('other::ark'), __('plugins.pubIds.ark.editor.preview.galleys', ['galleyLabel' => $galley->getGalleyLabel()])];
                    } else {
                        $arkTableRows[] = [$warningIconHtml . __('submission.status.unassigned'), __('plugins.pubIds.ark.editor.preview.galleys', ['galleyLabel' => $galley->getGalleyLabel()])];
                    }
                }
            }
            if (!empty($arkTableRows)) {
                $table = '<table class="pkpTable"><thead><tr>' .
                    '<th>' . __('plugins.pubIds.ark.displayName') . '</th>' .
                    '<th>' . __('plugins.pubIds.ark.editor.preview.objects') . '</th>' .
                    '</tr></thead><tbody>';
                foreach ($arkTableRows as $arkTableRow) {
                    $table .= '<tr><td>' . $arkTableRow[0] . '</td><td>' . $arkTableRow[1] . '</td></tr>';
                }
                $table .= '</tbody></table>';
            }
            $form->addField(new \PKP\components\forms\FieldHTML('ark', [
                'description' => $table,
                'groupId' => 'default',
            ]));
        }
    }

    /**
     * Load the FieldArk Vue.js component into Vue.js
     */
    public function loadArkFieldComponent(string $hookName, array $args): void
    {
        $templateMgr = $args[0];
        $template = $args[1];

        if ($template !== 'dashboard/editors.tpl') {
            return;
        }

        $context = Application::get()->getRequest()->getContext();
        $suffixType = $this->getSetting($context->getId(), 'arkSuffix');

        $appyCheckNumber = $this->getSetting($context->getId(), 'arkCheckNo');

        if ($appyCheckNumber) {
            // Load the checkNumber.js file that is required for ARK fields
            $this->addJavaScript(Application::get()->getRequest(), TemplateManager::getManager(Application::get()->getRequest()));
        }

        if ($suffixType === 'default' || $suffixType === 'pattern') {
            $templateMgr->addJavaScript(
                'field-pub-id-ark-component',
                Application::get()->getRequest()->getBaseUrl() . '/' . $this->getPluginPath() . '/js/FieldPubIdArk.js',
                [
                    'contexts' => 'backend',
                    'priority' => TemplateManager::STYLE_SEQUENCE_LAST,
                ]
            );
        } else {
            $templateMgr->addJavaScript(
                'field-text-ark-component',
                Application::get()->getRequest()->getBaseUrl() . '/' . $this->getPluginPath() . '/js/FieldTextArk.js',
                [
                    'contexts' => 'backend',
                    'priority' => TemplateManager::STYLE_SEQUENCE_LAST,
                ]
            );
            $templateMgr->addStyleSheet(
                'field-text-ark-component',
                '
                    .pkpFormField--ark__input {
                        display: inline-block;
                    }
                ',
                [
                    'contexts' => 'backend',
                    'inline' => true,
                    'priority' => TemplateManager::STYLE_SEQUENCE_LAST,
                ]
            );
        }
    }

    //
    // Private helper methods
    //
    /**
     * Get the last, check number.
     * Algorithm (s. http://www.persistent-identifier.de/?link=316):
     *  every ARK character is replaced with a number according to the conversion table,
     *  every number is multiplied by it's position/index (beginning with 1),
     *  the numbers' sum is calculated,
     *  the sum is divided by the last number,
     *  the last number of the quotient before the decimal point is the check number.
     */
    public function _calculateCheckNo($ark)
    {
        $arkLower = strtolower($ark);

        $conversionTable = ['9' => '41', '8' => '9', '7' => '8', '6' => '7', '5' => '6', '4' => '5', '3' => '4', '2' => '3', '1' => '2', '0' => '1', 'a' => '18', 'b' => '14', 'c' => '19', 'd' => '15', 'e' => '16', 'f' => '21', 'g' => '22', 'h' => '23', 'i' => '24', 'j' => '25', 'k' => '42', 'l' => '26', 'm' => '27', 'n' => '13', 'o' => '28', 'p' => '29', 'q' => '31', 'r' => '12', 's' => '32', 't' => '33', 'u' => '11', 'v' => '34', 'w' => '35', 'x' => '36', 'y' => '37', 'z' => '38', '-' => '39', ':' => '17', '_' => '43', '/' => '45', '.' => '47', '+' => '49'];

        $newARK = '';
        for ($i = 0; $i < strlen($arkLower); $i++) {
            $char = $arkLower[$i];
            $newARK .= $conversionTable[$char];
        }
        $sum = 0;
        for ($j = 1; $j <= strlen($newARK); $j++) {
            $sum = $sum + ($newARK[$j - 1] * $j);
        }

        $lastNumber = $newARK[strlen($newARK) - 1];
        $quot = $sum / $lastNumber;
        $quotRound = floor($quot);
        $quotString = (string)$quotRound;

        return $quotString[strlen($quotString) - 1];
    }
}

if (!PKP_STRICT_MODE) {
    class_alias('\APP\plugins\pubIds\ark\ARKPubIdPlugin', '\ARKPubIdPlugin');
}
