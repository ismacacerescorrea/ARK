/**
 * @defgroup plugins_pubIds_ark_js
 */
/**
 * @file plugins/pubIds/ark/js/FieldTextArk.js
 *
 * Copyright (c) 2014-2021 Simon Fraser University
 * Copyright (c) 2003-2021 John Willinsky
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @brief A Vue.js component for ARK text form field, that is used for custom suffixes.
 */

pkp.registry.registerComponent('FieldTextArk', {
	name: 'FieldTextArk',
	extends: pkp.registry.getComponent('PkpFieldText'),
	template:
		'<div class="pkpFormField pkpFormField--text pkpFormField--ark" :class="classes">' +
		'			<form-field-label' +
		'				:controlId="controlId"' +
		'				:label="label"' +
		'				:localeLabel="localeLabel"' +
		'				:isRequired="isRequired"' +
		'				:requiredLabel="t(\'common.required\')"' +
		'				:multilingualLabel="multilingualLabel"' +
		'			/>' +
		'			<div' +
		'				v-if="isPrimaryLocale && description"' +
		'				class="pkpFormField__description"' +
		'				v-strip-unsafe-html="description"' +
		'				:id="describedByDescriptionId"' +
		'			/>' +
		'			<div class="pkpFormField__control" :class="controlClasses">' +
		'				<input' +
		'					class="pkpFormField__input pkpFormField--text__input pkpFormField--ark__input"' +
		'					ref="input"' +
		'					v-model="currentValue"' +
		'					:type="inputType"' +
		'					:id="controlId"' +
		'					:name="localizedName"' +
		'					:aria-describedby="describedByIds"' +
		'					:aria-invalid="!!errors.length"' +
		'					:required="isRequired"' +
		'					:style="inputStyles"' +
		'				/>' +
		'				<pkp-button' +
		'					v-if="applyCheckNumber"' +
		'					@click.prevent="addCheckNumber"' +
		'					:disabled="currentValue === null || currentValue?.length === 0"' +
		'					style="display:none"' + // ocultamos sin eliminar la lógica
		'				>' +
		'					{{ addCheckNumberLabel }}' +
		'				</pkp-button>' +
		'				<field-error' +
		'					v-if="errors.length"' +
		'					:id="describedByErrorId"' +
		'					:messages="errors"' +
		'				/>' +
		'			</div>' +
		'		</div>',
	props: {
		addCheckNumberLabel: {
			type: String,
			required: true,
		},
		arkPrefix: {
			type: String,
			required: true,
		},
		applyCheckNumber: {
			type: Boolean,
			required: true,
		},
	},
	methods: {
		/**
		 * Placeholder method from URN plugin; kept for compatibility.
		 * ARK identifiers do not use a check number.
		 */
		addCheckNumber() {
			// La función queda inactiva en ARK
			// this.currentValue += $.pkp.plugins.generic.ark.getCheckNumber(...) no se usa
		},
	},
});
