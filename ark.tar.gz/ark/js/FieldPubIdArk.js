/**
 * @defgroup plugins_pubIds_ark_js
 */
/**
 * @file plugins/pubIds/ark/js/FieldPubIdArk.js
 *
 * Copyright (c) 2014-2021 Simon Fraser University
 * Copyright (c) 2003-2021 John Willinsky
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @brief A Vue.js component for ARK field, that is used for pattern suffixes and that considers check number.
 */

pkp.registry.registerComponent('FieldPubIdArk', {
    name: 'FieldPubIdArk',
    extends: pkp.registry.getComponent('PkpFieldPubId'),
    props: {
        applyCheckNumber: {
            type: Boolean,
            required: true
        }
    },
    methods: {
        generateId() {
            var id = pkp.registry.getComponent('PkpFieldPubId').methods['generateId'].apply(this);
            return this.applyCheckNumber
                ? id + $.pkp.plugins.generic.ark.getCheckNumber(id, this.prefix)
                : id;
        }
    },
})
