/**
 * @defgroup plugins_pubIds_ark_js
 */
/**
 * @file plugins/pubIds/ark/js/checkNumber.js
 *
 * Copyright (c) 2014-2021 Simon Fraser University
 * Copyright (c) 2003-2021 John Willinsky
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @brief Function for determining and adding the check number for ARKs (not applied)
 */
(function($) {

	/**
	 * Add method to the pkp namespace
	 */
	$.pkp.plugins.generic.ark = {

		/**
		 * This function is kept for compatibility but not used in ARK plugin.
		 */
		getCheckNumber: function(ark, arkPrefix) {
			var newARK = '',
					conversionTable = {
						'9': '41', '8': '9', '7': '8', '6': '7',
						'5': '6', '4': '5', '3': '4', '2': '3',
						'1': '2', '0': '1', 'a': '18', 'b': '14',
						'c': '19', 'd': '15', 'e': '16', 'f': '21',
						'g': '22', 'h': '23', 'i': '24', 'j': '25',
						'k': '42', 'l': '26', 'm': '27', 'n': '13',
						'o': '28', 'p': '29', 'q': '31', 'r': '12',
						's': '32', 't': '33', 'u': '11', 'v': '34',
						'w': '35', 'x': '36', 'y': '37', 'z': '38',
						'-': '39', ':': '17', '_': '43', '/': '45',
						'.': '47', '+': '49'
					},
					i, j, char, sum, lastNumber, quot, quotRound, quotString;

			var suffix = ark.replace(arkPrefix, '').toLowerCase();
			for (i = 0; i < suffix.length; i++) {
				char = suffix.charAt(i);
				newARK += conversionTable[char];
			}
			sum = 0;
			for (j = 1; j <= newARK.length; j++) {
				sum = sum + (newARK.charAt(j - 1) * j);
			}
			lastNumber = newARK.charAt(newARK.length - 1);
			quot = sum / lastNumber;
			quotRound = Math.floor(quot);
			quotString = quotRound.toString();
			return parseInt(quotString.charAt(quotString.length - 1));
		}
	};

	// Disabled in ARK: Check number is not used in this plugin
	/*
	$('#checkNo').on('click', () => {
		var arkPrefix = $('[id^="arkPrefix"]').val(),
				arkSuffix = $('[id^="arkSuffix"]').val();
		ark = arkPrefix + arkSuffix;
		$('[id^="arkSuffix"]').val(arkSuffix + $.pkp.plugins.generic.ark.getCheckNumber(ark, arkPrefix));
	});
	*/

}(jQuery));
